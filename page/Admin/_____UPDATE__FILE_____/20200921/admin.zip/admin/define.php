<?php
	//-----------Define All Page---------------------------------------------//
	DEFINE('PATH_INDEX_LOGOUT','index.php?page=true&logout=out');
	DEFINE('PATH_USER','index.php?user=true&page=user');
	DEFINE('PATH_APPS','index.php?apps=true&page=apps');
	DEFINE('PATH_PERM','index.php?perm=true&page=perm');
	DEFINE('PATH_GRUP','index.php?grup=true&page=grup');
	DEFINE('_ACCESS_',get_permitted(ACCESS,'access')); 
	
	//-----------Define add, delete, edit page-------------------------------//
	DEFINE('ADD','&add=ok');
	DEFINE('EDIT','&edit=ok');
	DEFINE('DELETE','&delete=ok');
	DEFINE('CHILD','&child=ok');
	DEFINE('UPLOAD','&upload=ok');
	DEFINE('POST','&post=ok');
	DEFINE('GEN','&gen=ok');
	DEFINE('WO','&wo=ok');
	DEFINE('PASS','&pass=ok');
	
	//-----------Define Root DIrectory --------------------------------------//
	DEFINE('_ROOT_','page/Admin/');
	
	//-----------Define title of this page ----------------------------------//
	DEFINE('_TITLE_','Administration');
	DEFINE('TUSER','MANAGE ALL USER');
	DEFINE('TAUSER','CREATE A NEW USER');
	DEFINE('EAUSER','EDIT USER FOR ');
	DEFINE('CAUSER','CHANGE PASSWORD USER FOR ');
	DEFINE('TAPPS','MANAGE APPLICATIONS');
	DEFINE('TAAPPS','CREATE A NEW APPLICATIONS');
	DEFINE('EAAPPS','EDIT APPLICATION ');
	DEFINE('TPERM','MANAGE PERMISSION');
	DEFINE('TAPERM','CREATE A NEW PERMISSION');
	DEFINE('EAPERM','EDIT PERMISSION ');
	DEFINE('TGRUP','GROUP');
	DEFINE('TAGRUP','CREATE A GROUP');
	DEFINE('EAGRUP','EDIT GROUP');
	
	//-----------Define title of for ----------------------------------//
	DEFINE('FAUSER','User');
	DEFINE('FAUSERPASS','Change Password');
	DEFINE('FAAPPS','Application');
	DEFINE('FAPERM','Permission');
	DEFINE('FAGRUP','Group');
	
	//-----------Define SQL Languange ---------------------------------------//
	DEFINE('USER','SELECT A.id_user User_ID, A.username Username, A.first_name First_Name, A.nick_name Nick_Name, A.last_name Last_Name, A.email Email, A.id_employee Id_employee, B.FirstName Employee FROM tb_user A LEFT JOIN employee B ON A.id_employee=B.EmployeeID');
	DEFINE('USERPASS','SELECT id_user, first_name First_Name, last_name Last_Name, password FROM tb_user');
	DEFINE('COUNTUSER','SELECT COUNT(*) FROM tb_user');
	DEFINE('APPS','SELECT id_apps Application_ID, application Application, description Description FROM tb_application');
	DEFINE('COUNTAPPS','SELECT COUNT(*) FROM tb_application');
	DEFINE('PERM','SELECT C.id_permit Permit_ID, C.user_p Username, C.application Application, D.group_name Group_Name FROM tb_permit C, tb_user_group D WHERE C.id_group=D.id_group');
	DEFINE('EPERM','SELECT id_permit, user_p, application, id_group FROM tb_permit');
	DEFINE('COUNTPERM','SELECT id_permit FROM tb_permit ORDER BY id_permit DESC LIMIT 0,1');
	DEFINE('GRUP','SELECT id_group ID_Group, group_name Group_Name, insert_data Insert_Data, view_data View_Data, delete_data Delete_Data, edit_data Edit_Data, full_control Full_Control FROM tb_user_group');
	
	//-----------For Combobox ---------------------------------------//
	DEFINE('COMUSER','SELECT username, username FROM tb_user ORDER BY username ASC');
	DEFINE('COMAPPS','SELECT application, application FROM tb_application ORDER BY application ASC');
	DEFINE('COMGRUP','SELECT id_group, group_name FROM tb_user_group ORDER BY group_name ASC');
	
	//-----------Graph Dashboard ---------------------------------------//
	DEFINE('GRAPHBYSTATE','SELECT WS.WorkStatus, COUNT(WS.WorkStatusID) FROM work_order WO, work_status WS WHERE WO.WorkStatusID=WS.WorkStatusID GROUP BY WS.WorkStatusID');
	
	//-----------Define global variable ----------------------------//
	unset($_SESSION['inquery']); unset($_SESSION['startdate']); unset($_SESSION['compdate']); unset($_SESSION['nextdate']); unset($_SESSION['pmid']);
	
	
?>