<?php
//==================Kumpulan halaman php yang didefinisikan dalam developer=================
	require_once(_ROOT_.'function/data/get_ssql.php');
	require_once(_ROOT_.'function/get_library.php');
	require_once(_ROOT_.'function/get_js.php');
	require_once(_ROOT_.'function/get_plugin.php');
	require_once(_ROOT_.'function/get_page.php');
	require_once(_ROOT_.'function/get_page_con1.php');
	//***********content ************************//
	require_once(_ROOT_.'function/get_new_page.php');
	require_once(_ROOT_.'function/content/export_work_order.php');
	require_once(_ROOT_.'function/content/export_asset.php');
	
	require_once(_ROOT_.'function/get_access_control.php');
	
?>